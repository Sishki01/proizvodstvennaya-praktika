from user_interface import get_user_input, process_user_request

def main():
    while True:
        image_path, operation = get_user_input()

        if image_path and operation:
            process_user_request(image_path, operation)
        else:
            print("Не удалось обработать запрос.")
        
        continue_choice = input("\nХотите обработать еще одно изображение? (да/нет): ").strip().lower()
        if continue_choice not in ["да", 'д', 'yes', 'y']:
            print("\nПрограмма завершена.")
            break

if __name__ == "__main__":
    main()