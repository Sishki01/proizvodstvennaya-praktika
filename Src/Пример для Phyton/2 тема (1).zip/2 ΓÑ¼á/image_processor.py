from PIL import Image
import os
import shutil

def get_results_folder():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    results_folder = os.path.join(current_dir, 'Результаты')
    
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)
        print(f"Создана папка для результатов: {results_folder}")
    
    return results_folder

def change_image_format(input_path, output_format):
    try:
        img = Image.open(input_path)
        pillow_format = 'JPEG' if output_format.upper() == 'JPG' else output_format.upper()
        results_folder = get_results_folder()
        
        original_name = os.path.splitext(os.path.basename(input_path))[0]
        new_extension = '.jpg' if output_format.upper() == 'JPG' else '.png'
        new_filename = f"{original_name}_converted{new_extension}"
        output_path = os.path.join(results_folder, new_filename)
        
        if pillow_format == 'JPEG' and img.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = background
        elif img.mode == 'P':
            img = img.convert('RGB')
        
        img.save(output_path, pillow_format)
        print(f"Изображение успешно конвертировано: {output_path}")
        return output_path

    except Exception as e:
        print(f"Ошибка при конвертации: {e}")
        return None

def move_image(file_path, destination_folder=None):
    try:
        if destination_folder is None:
            destination_folder = get_results_folder()
        elif not os.path.exists(destination_folder):
            os.makedirs(destination_folder)

        file_name = os.path.basename(file_path)
        new_path = os.path.join(destination_folder, file_name)
        
        counter = 1
        base_name, extension = os.path.splitext(file_name)
        while os.path.exists(new_path):
            new_filename = f"{base_name}_{counter}{extension}"
            new_path = os.path.join(destination_folder, new_filename)
            counter += 1

        shutil.move(file_path, new_path)
        print(f"Изображение успешно перемещено: {new_path}")
        return new_path
    except Exception as e:
        print(f"Ошибка при перемещении: {e}")
        return None

def get_image_info(image_path):
    try:
        img = Image.open(image_path)
        file_stats = os.stat(image_path)

        info = {
            "Размер файла": f"{file_stats.st_size / 1024:.2f} KB",
            "Разрешение": f"{img.width} x {img.height}",
            "Формат": img.format,
            "Режим": img.mode,
            "Дата создания": f"{os.path.getctime(image_path):.0f}",
            "Дата изменения": f"{os.path.getmtime(image_path):.0f}"
        }

        return info
    except Exception as e:
        print(f"Ошибка при получении информации: {e}")
        return None