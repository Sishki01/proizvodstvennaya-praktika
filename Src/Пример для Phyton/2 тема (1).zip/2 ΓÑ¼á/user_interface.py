import os
from image_processor import change_image_format, move_image, get_image_info

def get_user_input():
    image_path = input("Введите путь к изображению: ").strip()
    image_path = image_path.strip('"')
    
    if not os.path.exists(image_path):
        print("Файл не найден")
        return None, None
    
    if not image_path.lower().endswith((".png", ".jpg", ".jpeg")):
        print("Поддерживаются только PNG и JPG файлы.")
        return None, None
    
    print("\nДоступные операции:")
    print("1 - Конвертировать в JPG")
    print("2 - Конвертировать в PNG")
    print("3 - Переместить файл в другую папку")
    print("4 - Получить информацию об изображении")

    choice = input("Выберите операцию (1/2/3/4): ").strip()

    if choice in ['1', '2']:
        format_type = 'JPG' if choice == '1' else 'PNG'
        return image_path, ('convert', format_type)
    elif choice == '3':
        dest_folder = input("Введите путь к папке назначения: ").strip()
        dest_folder = dest_folder.strip('"')
        return image_path, ('move', dest_folder)
    elif choice == '4':
        return image_path, ('info', None)
    else:
        print("Неверный выбор")
        return None, None

def process_user_request(image_path, operation):
    op_type, value = operation
    
    if op_type == 'convert':
        new_path = change_image_format(image_path, value)
        if not new_path:
            print("Ошибка конвертации")
        else:
            print(f"Файл успешно сохранен в: {new_path}")
    
    elif op_type == 'move':
        new_path = move_image(image_path, value)
        if not new_path:
            print("Ошибка перемещения")
        else:
            print(f"Файл успешно перемещен в: {new_path}")
    
    elif op_type == 'info':
        info = get_image_info(image_path)
        if info:
            print("Информация об изображении:")
            for key, value in info.items():
                print(f"   {key}: {value}")
        else:
            print("Не удалось получить информацию об изображении")